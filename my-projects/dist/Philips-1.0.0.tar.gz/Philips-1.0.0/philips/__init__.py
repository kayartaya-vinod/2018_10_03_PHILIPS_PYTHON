'''This is a demo package created for training
at Philips in October 2018.

Name: philips
Version: 1.0.0
Author: Vinod Kumar
Email: vinod@vinod.co
'''

# variables common for the modules in the package
author_name = 'Vinod'
author_email = 'vinod@vinod.co'
