if __name__=='__main__':
    print('Author name: ', author_name)
    print('Author email: ', author_email)