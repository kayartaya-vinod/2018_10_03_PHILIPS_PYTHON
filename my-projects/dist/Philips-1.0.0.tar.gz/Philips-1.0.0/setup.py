from setuptools import setup

setup(
    name = 'Philips',
    version = '1.0.0',
    description = 'A bunch of utility functions created during classroom practice',
    author = 'Vinod',
    author_email = 'vinod@vinod.co',
    packages = ['philips']
)